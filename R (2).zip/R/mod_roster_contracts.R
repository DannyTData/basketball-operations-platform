#' Roster and contracts Server Functions
#' @noRd
mod_roster_contracts_server <- function(
    id,
    selected_team,
    selected_season
) {
  
  shiny::moduleServer(id, function(input, output, session) {
    
    # ----------------------------------------------------------
    # Retrieve the selected team's active roster from SQLite
    # ----------------------------------------------------------
    
    selected_roster <- shiny::reactive({
      
      shiny::req(
        selected_team(),
        selected_season()
      )
      
      db_path <- "inst/database/tbi.sqlite"
      
      if (!file.exists(db_path)) {
        stop("TBI database not found: ", db_path)
      }
      
      con <- DBI::dbConnect(
        RSQLite::SQLite(),
        dbname = db_path
      )
      
      on.exit(
        {
          if (DBI::dbIsValid(con)) {
            DBI::dbDisconnect(con)
          }
        },
        add = TRUE
      )
      
      DBI::dbGetQuery(
        con,
        "
        SELECT
          t.team_name,
          t.abbreviation,
          rh.season,
          p.player_name AS player,
          p.primary_position AS position,
          p.height_inches,
          p.weight_lbs,
          NULL AS age,
          NULL AS salary,
          NULL AS contract,
          rh.roster_status AS status
        FROM roster_history rh
        INNER JOIN players p
          ON rh.player_id = p.player_id
        INNER JOIN teams t
          ON rh.team_id = t.team_id
        WHERE t.team_name = ?
          AND rh.season = ?
          AND rh.roster_status = 'Active'
        ORDER BY
          CASE
            WHEN p.primary_position LIKE 'PG%' THEN 1
            WHEN p.primary_position LIKE 'SG%' THEN 2
            WHEN p.primary_position LIKE 'SF%' THEN 3
            WHEN p.primary_position LIKE 'PF%' THEN 4
            WHEN p.primary_position LIKE 'C%' THEN 5
            ELSE 6
          END,
          p.player_name
        ",
        params = list(
          selected_team(),
          selected_season()
        )
      )
    })
    
    # ----------------------------------------------------------
    # Active player summary
    # ----------------------------------------------------------
    
    output$active_players <- shiny::renderText({
      
      nrow(selected_roster())
    })
    
    output$active_players_detail <- shiny::renderText({
      
      player_count <- nrow(selected_roster())
      
      if (player_count == 0) {
        return("No roster data available")
      }
      
      standard_roster_limit <- 18
      
      paste(
        max(0, standard_roster_limit - player_count),
        "roster openings"
      )
    })
    
    # ----------------------------------------------------------
    # Average age summary
    # Age remains unavailable until birth dates are loaded
    # ----------------------------------------------------------
    
    output$average_age <- shiny::renderText({
      
      roster <- selected_roster()
      
      if (
        nrow(roster) == 0 ||
        all(is.na(roster$age))
      ) {
        return("--")
      }
      
      sprintf(
        "%.1f",
        mean(
          roster$age,
          na.rm = TRUE
        )
      )
    })
    
    output$average_age_detail <- shiny::renderText({
      
      roster <- selected_roster()
      
      if (
        nrow(roster) == 0 ||
        all(is.na(roster$age))
      ) {
        return("Age data not loaded")
      }
      
      average_age <- mean(
        roster$age,
        na.rm = TRUE
      )
      
      if (average_age < 25) {
        "Young development timeline"
      } else if (average_age < 28) {
        "Prime competitive window"
      } else {
        "Veteran roster timeline"
      }
    })
    
    # ----------------------------------------------------------
    # Payroll summary
    # Payroll remains unavailable until contracts are loaded
    # ----------------------------------------------------------
    
    output$total_payroll <- shiny::renderText({
      
      roster <- selected_roster()
      
      if (
        nrow(roster) == 0 ||
        all(is.na(roster$salary))
      ) {
        return("--")
      }
      
      payroll <- sum(
        roster$salary,
        na.rm = TRUE
      )
      
      paste0(
        "$",
        format(
          round(payroll / 1000000, 1),
          nsmall = 1
        ),
        "M"
      )
    })
    
    output$payroll_detail <- shiny::renderText({
      
      roster <- selected_roster()
      
      if (
        nrow(roster) == 0 ||
        all(is.na(roster$salary))
      ) {
        return("Contract data not loaded")
      }
      
      payroll <- sum(
        roster$salary,
        na.rm = TRUE
      )
      
      if (payroll >= 180000000) {
        "High payroll commitment"
      } else if (payroll >= 140000000) {
        "Moderate payroll flexibility"
      } else {
        "Strong payroll flexibility"
      }
    })
    
    # ----------------------------------------------------------
    # Roster grade
    # Grade remains unavailable until age and payroll exist
    # ----------------------------------------------------------
    
    output$roster_grade <- shiny::renderText({
      
      roster <- selected_roster()
      
      if (nrow(roster) == 0) {
        return("--")
      }
      
      if (
        all(is.na(roster$age)) ||
        all(is.na(roster$salary))
      ) {
        return("N/A")
      }
      
      average_age <- mean(
        roster$age,
        na.rm = TRUE
      )
      
      payroll <- sum(
        roster$salary,
        na.rm = TRUE
      )
      
      if (
        average_age >= 24 &&
        average_age <= 28 &&
        payroll >= 140000000
      ) {
        "A-"
      } else if (
        average_age <= 29 &&
        payroll >= 110000000
      ) {
        "B+"
      } else {
        "B"
      }
    })
    
    output$roster_grade_detail <- shiny::renderText({
      
      roster <- selected_roster()
      
      if (nrow(roster) == 0) {
        return("Roster evaluation unavailable")
      }
      
      if (
        all(is.na(roster$age)) ||
        all(is.na(roster$salary))
      ) {
        return("Awaiting age and contract data")
      }
      
      average_age <- mean(
        roster$age,
        na.rm = TRUE
      )
      
      if (average_age <= 27) {
        "Balanced competitive timeline"
      } else {
        "Veteran-focused construction"
      }
    })
    
    # ----------------------------------------------------------
    # Roster count badge
    # ----------------------------------------------------------
    
    output$roster_count_badge <- shiny::renderUI({
      
      shiny::span(
        class = "roster-panel-badge",
        paste(
          nrow(selected_roster()),
          "Players"
        )
      )
    })
    
    # ----------------------------------------------------------
    # Active roster table
    # ----------------------------------------------------------
    
    output$roster_table <- shiny::renderTable({
      
      roster <- selected_roster()
      
      shiny::validate(
        shiny::need(
          nrow(roster) > 0,
          paste(
            "No roster data is currently available for",
            selected_team(),
            "during",
            selected_season()
          )
        )
      )
      
      age_display <- ifelse(
        is.na(roster$age),
        "--",
        as.character(roster$age)
      )
      
      salary_display <- ifelse(
        is.na(roster$salary),
        "--",
        paste0(
          "$",
          format(
            round(roster$salary / 1000000, 1),
            nsmall = 1
          ),
          "M"
        )
      )
      
      contract_display <- ifelse(
        is.na(roster$contract) |
          trimws(as.character(roster$contract)) == "",
        "Not loaded",
        as.character(roster$contract)
      )
      
      data.frame(
        Player = roster$player,
        Position = roster$position,
        Age = age_display,
        Salary = salary_display,
        Contract = contract_display,
        Status = roster$status,
        check.names = FALSE,
        stringsAsFactors = FALSE
      )
      
    },
    striped = FALSE,
    bordered = FALSE,
    hover = TRUE,
    spacing = "s",
    width = "100%"
    )
  })
}