#' Roster and contracts UI Function
#' @noRd
mod_roster_contracts_ui <- function(id) {
  
  ns <- shiny::NS(id)
  
  shiny::div(
    class = "roster-intelligence-page",
    
    # ----------------------------------------------------------
    # Page heading
    # ----------------------------------------------------------
    
    shiny::div(
      class = "roster-page-heading",
      
      shiny::div(
        class = "roster-page-eyebrow",
        "ROSTER CONSTRUCTION"
      ),
      
      shiny::h2(
        class = "roster-page-title",
        "Roster Intelligence"
      ),
      
      shiny::p(
        class = "roster-page-description",
        paste(
          "Evaluate roster balance, player timelines,",
          "contract structure, and positional depth."
        )
      )
    ),
    
    # ----------------------------------------------------------
    # Dynamic summary cards
    # ----------------------------------------------------------
    
    shiny::div(
      class = "roster-summary-grid",
      
      roster_summary_card(
        icon = "award",
        label = "ROSTER GRADE",
        value = shiny::textOutput(
          ns("roster_grade"),
          inline = TRUE
        ),
        detail = shiny::textOutput(
          ns("roster_grade_detail"),
          inline = TRUE
        )
      ),
      
      roster_summary_card(
        icon = "calendar3",
        label = "AVERAGE AGE",
        value = shiny::textOutput(
          ns("average_age"),
          inline = TRUE
        ),
        detail = shiny::textOutput(
          ns("average_age_detail"),
          inline = TRUE
        )
      ),
      
      roster_summary_card(
        icon = "cash-stack",
        label = "TOTAL PAYROLL",
        value = shiny::textOutput(
          ns("total_payroll"),
          inline = TRUE
        ),
        detail = shiny::textOutput(
          ns("payroll_detail"),
          inline = TRUE
        )
      ),
      
      roster_summary_card(
        icon = "people",
        label = "ACTIVE PLAYERS",
        value = shiny::textOutput(
          ns("active_players"),
          inline = TRUE
        ),
        detail = shiny::textOutput(
          ns("active_players_detail"),
          inline = TRUE
        )
      )
    ),
    
    # ----------------------------------------------------------
    # Main roster and depth-chart area
    # ----------------------------------------------------------
    
    shiny::div(
      class = "roster-main-grid",
      
      shiny::div(
        class = "roster-panel roster-table-panel",
        
        shiny::div(
          class = "roster-panel-header",
          
          shiny::div(
            shiny::div(
              class = "roster-panel-eyebrow",
              "PERSONNEL"
            ),
            
            shiny::h3(
              class = "roster-panel-title",
              "Active Roster"
            )
          ),
          
          shiny::uiOutput(
            ns("roster_count_badge")
          )
        ),
        
        shiny::div(
          class = "roster-table-wrapper",
          
          shiny::tableOutput(
            ns("roster_table")
          )
        )
      ),
      
      shiny::div(
        class = "roster-panel roster-depth-panel",
        
        shiny::div(
          class = "roster-panel-header",
          
          shiny::div(
            shiny::div(
              class = "roster-panel-eyebrow",
              "ROTATION"
            ),
            
            shiny::h3(
              class = "roster-panel-title",
              "Depth Chart"
            )
          )
        ),
        
        shiny::div(
          class = "depth-chart",
          
          depth_chart_row(
            position = "PG",
            starter = "Starting Guard",
            reserve = "Primary Reserve"
          ),
          
          depth_chart_row(
            position = "SG",
            starter = "Starting Guard",
            reserve = "Primary Reserve"
          ),
          
          depth_chart_row(
            position = "SF",
            starter = "Starting Wing",
            reserve = "Primary Reserve"
          ),
          
          depth_chart_row(
            position = "PF",
            starter = "Starting Forward",
            reserve = "Primary Reserve"
          ),
          
          depth_chart_row(
            position = "C",
            starter = "Starting Center",
            reserve = "Primary Reserve"
          )
        )
      )
    ),
    
    # ----------------------------------------------------------
    # Bottom analysis panels
    # ----------------------------------------------------------
    
    shiny::div(
      class = "roster-bottom-grid",
      
      shiny::div(
        class = "roster-panel",
        
        shiny::div(
          class = "roster-panel-header",
          
          shiny::div(
            shiny::div(
              class = "roster-panel-eyebrow",
              "POSITIONAL ANALYSIS"
            ),
            
            shiny::h3(
              class = "roster-panel-title",
              "Position Strength"
            )
          )
        ),
        
        position_strength_row(
          position = "Point Guard",
          score = 82
        ),
        
        position_strength_row(
          position = "Shooting Guard",
          score = 88
        ),
        
        position_strength_row(
          position = "Small Forward",
          score = 92
        ),
        
        position_strength_row(
          position = "Power Forward",
          score = 79
        ),
        
        position_strength_row(
          position = "Center",
          score = 68
        )
      ),
      
      shiny::div(
        class = "roster-panel",
        
        shiny::div(
          class = "roster-panel-header",
          
          shiny::div(
            shiny::div(
              class = "roster-panel-eyebrow",
              "EXECUTIVE BRIEF"
            ),
            
            shiny::h3(
              class = "roster-panel-title",
              "Roster Assessment"
            )
          )
        ),
        
        shiny::tags$ul(
          class = "roster-assessment-list",
          
          shiny::tags$li(
            "The current core is positioned inside its prime competitive window."
          ),
          
          shiny::tags$li(
            "Wing depth projects as the strongest area of the roster."
          ),
          
          shiny::tags$li(
            "Frontcourt depth should remain a priority in future transactions."
          ),
          
          shiny::tags$li(
            "Payroll commitments limit near-term flexibility."
          )
        )
      )
    )
  )
}
#' Roster and contracts Server Functions
#' @noRd
mod_roster_contracts_server <- function(
    id,
    selected_team,
    selected_season
) {
  
  shiny::moduleServer#' Roster and contracts UI Function
  #' @noRd
  mod_roster_contracts_ui <- function(id) {
    ns <- shiny::NS(id)
    
    shiny::div(
      class = "roster-intelligence-page",
      
      shiny::div(
        class = "roster-page-heading",
        shiny::div(class = "roster-page-eyebrow", "ROSTER CONSTRUCTION"),
        shiny::h2(class = "roster-page-title", "Roster Intelligence"),
        shiny::p(
          class = "roster-page-description",
          paste(
            "Evaluate roster balance, player timelines,",
            "contract structure, and positional depth."
          )
        )
      ),
      
      shiny::div(
        class = "roster-summary-grid",
        roster_summary_card(
          icon = "award",
          label = "ROSTER GRADE",
          value = shiny::textOutput(ns("roster_grade"), inline = TRUE),
          detail = shiny::textOutput(ns("roster_grade_detail"), inline = TRUE)
        ),
        roster_summary_card(
          icon = "calendar3",
          label = "AVERAGE AGE",
          value = shiny::textOutput(ns("average_age"), inline = TRUE),
          detail = shiny::textOutput(ns("average_age_detail"), inline = TRUE)
        ),
        roster_summary_card(
          icon = "cash-stack",
          label = "TOTAL PAYROLL",
          value = shiny::textOutput(ns("total_payroll"), inline = TRUE),
          detail = shiny::textOutput(ns("payroll_detail"), inline = TRUE)
        ),
        roster_summary_card(
          icon = "people",
          label = "ACTIVE PLAYERS",
          value = shiny::textOutput(ns("active_players"), inline = TRUE),
          detail = shiny::textOutput(ns("active_players_detail"), inline = TRUE)
        )
      ),
      
      shiny::div(
        class = "roster-main-grid",
        shiny::div(
          class = "roster-panel roster-table-panel",
          shiny::div(
            class = "roster-panel-header",
            shiny::div(
              shiny::div(class = "roster-panel-eyebrow", "PERSONNEL"),
              shiny::h3(class = "roster-panel-title", "Active Roster")
            ),
            shiny::uiOutput(ns("roster_count_badge"))
          ),
          shiny::div(
            class = "roster-table-wrapper",
            shiny::tableOutput(ns("roster_table"))
          )
        ),
        
        shiny::div(
          class = "roster-panel roster-depth-panel",
          shiny::div(
            class = "roster-panel-header",
            shiny::div(
              shiny::div(class = "roster-panel-eyebrow", "ROTATION"),
              shiny::h3(class = "roster-panel-title", "Depth Chart")
            )
          ),
          shiny::uiOutput(ns("depth_chart_ui"))
        )
      ),
      
      shiny::div(
        class = "roster-bottom-grid",
        shiny::div(
          class = "roster-panel",
          shiny::div(
            class = "roster-panel-header",
            shiny::div(
              shiny::div(class = "roster-panel-eyebrow", "POSITIONAL ANALYSIS"),
              shiny::h3(class = "roster-panel-title", "Position Strength")
            )
          ),
          shiny::uiOutput(ns("position_strength_ui"))
        ),
        
        shiny::div(
          class = "roster-panel",
          shiny::div(
            class = "roster-panel-header",
            shiny::div(
              shiny::div(class = "roster-panel-eyebrow", "EXECUTIVE BRIEF"),
              shiny::h3(class = "roster-panel-title", "Roster Assessment")
            )
          ),
          shiny::uiOutput(ns("roster_assessment_ui"))
        )
      )
    )
  }
  
  #' Roster and contracts Server Functions
  #' @noRd
  mod_roster_contracts_server <- function(id, selected_team, selected_season) {
    shiny::moduleServer(id, function(input, output, session) {
      
      database_path <- function() {
        development_path <- file.path("inst", "database", "tbi.sqlite")
        
        if (file.exists(development_path)) {
          return(development_path)
        }
        
        installed_path <- system.file(
          "database",
          "tbi.sqlite",
          package = utils::packageName()
        )
        
        if (nzchar(installed_path) && file.exists(installed_path)) {
          return(installed_path)
        }
        
        stop("TBI database not found at inst/database/tbi.sqlite")
      }
      
      selected_roster <- shiny::reactive({
        shiny::req(selected_team(), selected_season())
        
        con <- DBI::dbConnect(
          RSQLite::SQLite(),
          dbname = database_path()
        )
        on.exit(DBI::dbDisconnect(con), add = TRUE)
        
        DBI::dbGetQuery(
          con,
          "
        SELECT
          t.team_name,
          t.abbreviation,
          rh.season,
          p.player_name AS player,
          p.primary_position AS position,
          p.height_inches,
          p.weight_lbs,
          NULL AS age,
          NULL AS salary,
          NULL AS contract,
          rh.roster_status AS status
        FROM roster_history rh
        INNER JOIN players p ON rh.player_id = p.player_id
        INNER JOIN teams t ON rh.team_id = t.team_id
        WHERE t.team_name = ?
          AND rh.season = ?
          AND LOWER(rh.roster_status) = 'active'
        ORDER BY
          CASE
            WHEN p.primary_position LIKE 'PG%' THEN 1
            WHEN p.primary_position LIKE 'SG%' THEN 2
            WHEN p.primary_position LIKE 'SF%' THEN 3
            WHEN p.primary_position LIKE 'PF%' THEN 4
            WHEN p.primary_position LIKE 'C%' THEN 5
            ELSE 6
          END,
          p.player_name
        ",
          params = list(selected_team(), selected_season())
        )
      })
      
      normalized_position <- function(position) {
        position <- toupper(trimws(ifelse(is.na(position), "", position)))
        
        if (grepl("PG", position, fixed = TRUE)) return("PG")
        if (grepl("SG", position, fixed = TRUE)) return("SG")
        if (grepl("SF", position, fixed = TRUE)) return("SF")
        if (grepl("PF", position, fixed = TRUE)) return("PF")
        if (position == "C" || grepl("CENTER", position)) return("C")
        if (position == "G") return("PG")
        if (position == "F") return("SF")
        
        "OTHER"
      }
      
      depth_chart_data <- shiny::reactive({
        roster <- selected_roster()
        positions <- c("PG", "SG", "SF", "PF", "C")
        
        if (nrow(roster) == 0) {
          return(data.frame(
            position = positions,
            starter = "No player available",
            reserve = "No reserve available",
            stringsAsFactors = FALSE
          ))
        }
        
        roster$position_group <- vapply(
          roster$position,
          normalized_position,
          character(1)
        )
        
        rows <- lapply(positions, function(pos) {
          players <- roster$player[roster$position_group == pos]
          
          data.frame(
            position = pos,
            starter = if (length(players) >= 1) players[[1]] else "No player available",
            reserve = if (length(players) >= 2) players[[2]] else "No reserve available",
            stringsAsFactors = FALSE
          )
        })
        
        do.call(rbind, rows)
      })
      
      output$active_players <- shiny::renderText(nrow(selected_roster()))
      
      output$active_players_detail <- shiny::renderText({
        player_count <- nrow(selected_roster())
        if (player_count == 0) return("No roster data available")
        paste(max(0, 18 - player_count), "roster openings")
      })
      
      output$average_age <- shiny::renderText({
        roster <- selected_roster()
        if (nrow(roster) == 0 || all(is.na(roster$age))) return("--")
        sprintf("%.1f", mean(roster$age, na.rm = TRUE))
      })
      
      output$average_age_detail <- shiny::renderText({
        roster <- selected_roster()
        if (nrow(roster) == 0 || all(is.na(roster$age))) return("Age data not loaded")
        
        average_age <- mean(roster$age, na.rm = TRUE)
        if (average_age < 25) {
          "Young development timeline"
        } else if (average_age < 28) {
          "Prime competitive window"
        } else {
          "Veteran roster timeline"
        }
      })
      
      output$total_payroll <- shiny::renderText({
        roster <- selected_roster()
        if (nrow(roster) == 0 || all(is.na(roster$salary))) return("--")
        
        paste0(
          "$",
          format(round(sum(roster$salary, na.rm = TRUE) / 1e6, 1), nsmall = 1),
          "M"
        )
      })
      
      output$payroll_detail <- shiny::renderText({
        roster <- selected_roster()
        if (nrow(roster) == 0 || all(is.na(roster$salary))) {
          return("Contract data not loaded")
        }
        
        payroll <- sum(roster$salary, na.rm = TRUE)
        if (payroll >= 180e6) {
          "High payroll commitment"
        } else if (payroll >= 140e6) {
          "Moderate payroll flexibility"
        } else {
          "Strong payroll flexibility"
        }
      })
      
      output$roster_grade <- shiny::renderText({
        roster <- selected_roster()
        if (nrow(roster) == 0) return("--")
        if (all(is.na(roster$age)) || all(is.na(roster$salary))) return("N/A")
        
        average_age <- mean(roster$age, na.rm = TRUE)
        payroll <- sum(roster$salary, na.rm = TRUE)
        
        if (average_age >= 24 && average_age <= 28 && payroll >= 140e6) {
          "A-"
        } else if (average_age <= 29 && payroll >= 110e6) {
          "B+"
        } else {
          "B"
        }
      })
      
      output$roster_grade_detail <- shiny::renderText({
        roster <- selected_roster()
        if (nrow(roster) == 0) return("Roster evaluation unavailable")
        if (all(is.na(roster$age)) || all(is.na(roster$salary))) {
          return("Awaiting age and contract data")
        }
        
        if (mean(roster$age, na.rm = TRUE) <= 27) {
          "Balanced competitive timeline"
        } else {
          "Veteran-focused construction"
        }
      })
      
      output$roster_count_badge <- shiny::renderUI({
        shiny::span(
          class = "roster-panel-badge",
          paste(nrow(selected_roster()), "Players")
        )
      })
      
      output$roster_table <- shiny::renderTable({
        roster <- selected_roster()
        
        shiny::validate(
          shiny::need(
            nrow(roster) > 0,
            paste(
              "No roster data is currently available for",
              selected_team(),
              "during",
              selected_season()
            )
          )
        )
        
        data.frame(
          Player = roster$player,
          Position = ifelse(is.na(roster$position), "--", roster$position),
          Age = ifelse(is.na(roster$age), "--", as.character(roster$age)),
          Salary = ifelse(
            is.na(roster$salary),
            "--",
            paste0(
              "$",
              format(round(roster$salary / 1e6, 1), nsmall = 1),
              "M"
            )
          ),
          Contract = ifelse(
            is.na(roster$contract) | trimws(as.character(roster$contract)) == "",
            "Not loaded",
            as.character(roster$contract)
          ),
          Status = roster$status,
          check.names = FALSE,
          stringsAsFactors = FALSE
        )
      },
      striped = FALSE,
      bordered = FALSE,
      hover = TRUE,
      spacing = "s",
      width = "100%"
      )
      
      output$depth_chart_ui <- shiny::renderUI({
        depth <- depth_chart_data()
        
        shiny::div(
          class = "depth-chart",
          lapply(seq_len(nrow(depth)), function(i) {
            depth_chart_row(
              position = depth$position[[i]],
              starter = depth$starter[[i]],
              reserve = depth$reserve[[i]]
            )
          })
        )
      })
      
      output$position_strength_ui <- shiny::renderUI({
        roster <- selected_roster()
        position_names <- c(
          PG = "Point Guard",
          SG = "Shooting Guard",
          SF = "Small Forward",
          PF = "Power Forward",
          C = "Center"
        )
        
        if (nrow(roster) == 0) {
          return(shiny::p("No positional data available."))
        }
        
        roster$position_group <- vapply(
          roster$position,
          normalized_position,
          character(1)
        )
        
        counts <- table(factor(roster$position_group, levels = names(position_names)))
        scores <- pmin(100, as.integer(counts) * 35)
        
        shiny::tagList(
          lapply(seq_along(position_names), function(i) {
            position_strength_row(
              position = unname(position_names[[i]]),
              score = scores[[i]]
            )
          })
        )
      })
      
      output$roster_assessment_ui <- shiny::renderUI({
        roster <- selected_roster()
        
        if (nrow(roster) == 0) {
          return(
            shiny::tags$ul(
              class = "roster-assessment-list",
              shiny::tags$li("No roster data is available for this selection.")
            )
          )
        }
        
        roster$position_group <- vapply(
          roster$position,
          normalized_position,
          character(1)
        )
        counts <- table(factor(roster$position_group, levels = c("PG", "SG", "SF", "PF", "C")))
        strongest <- names(counts)[which.max(counts)]
        weakest <- names(counts)[which.min(counts)]
        
        shiny::tags$ul(
          class = "roster-assessment-list",
          shiny::tags$li(paste(nrow(roster), "active players are loaded from SQLite.")),
          shiny::tags$li(paste(strongest, "currently has the greatest listed depth.")),
          shiny::tags$li(paste(weakest, "currently has the least listed depth.")),
          shiny::tags$li("Age, salary, and contract analysis will activate after those ETLs are loaded.")
        )
      })
    })
  }
}