#' Roster board UI
#'
#' @param id Shiny module ID
#'
#' @return Shiny UI
mod_roster_board_ui <- function(id) {
  ns <- shiny::NS(id)
  
  shiny::tagList(
    shiny::fluidRow(
      shiny::column(
        width = 4,
        shiny::selectInput(
          inputId = ns("team_id"),
          label = "Team",
          choices = NULL
        )
      )
    ),
    
    shiny::uiOutput(ns("roster_board"))
  )
}


#' Roster board server
#'
#' @param id Shiny module ID
#' @param db_path Path to the SQLite database
#'
#' @return Selected player reactive
mod_roster_board_server <- function(
    id,
    db_path = "inst/database/tbi.sqlite"
) {
  shiny::moduleServer(id, function(input, output, session) {
    
    con <- DBI::dbConnect(
      RSQLite::SQLite(),
      db_path
    )
    
    session$onSessionEnded(function() {
      if (DBI::dbIsValid(con)) {
        DBI::dbDisconnect(con)
      }
    })
    
    teams <- DBI::dbGetQuery(
      con,
      "
      SELECT
          team_id,
          team_name
      FROM teams
      ORDER BY team_name
      "
    )
    
    default_team <- teams$team_id[
      teams$team_name == "Boston Celtics"
    ]
    
    if (length(default_team) == 0) {
      default_team <- teams$team_id[[1]]
    }
    
    shiny::updateSelectInput(
      session = session,
      inputId = "team_id",
      choices = stats::setNames(
        teams$team_id,
        teams$team_name
      ),
      selected = default_team[[1]]
    )
    
    roster_data <- shiny::reactive({
      shiny::req(input$team_id)
      
      DBI::dbGetQuery(
        con,
        "
        SELECT
            dc.player_id,
            p.player_name,
            p.player_age,
            p.height_inches,
            p.weight_lbs,
            dc.position,
            dc.depth_order,
            dc.is_starter
        FROM depth_chart dc
        INNER JOIN players p
            ON dc.player_id = p.player_id
        WHERE dc.team_id = ?
        ORDER BY
            CASE dc.position
                WHEN 'PG' THEN 1
                WHEN 'SG' THEN 2
                WHEN 'SF' THEN 3
                WHEN 'PF' THEN 4
                WHEN 'C' THEN 5
                ELSE 6
            END,
            dc.depth_order
        ",
        params = list(as.integer(input$team_id))
      )
    })
    
    selected_player_id <- shiny::reactiveVal(NULL)
    
    shiny::observeEvent(input$selected_player, {
      selected_player_id(
        as.integer(input$selected_player)
      )
    })
    
    output$roster_board <- shiny::renderUI({
      roster <- roster_data()
      
      shiny::validate(
        shiny::need(
          nrow(roster) > 0,
          "No depth-chart data is available for this team."
        )
      )
      
      positions <- c("PG", "SG", "SF", "PF", "C")
      
      shiny::div(
        class = "tbi-roster-board",
        
        lapply(positions, function(pos) {
          
          players <- roster[
            roster$position == pos,
            ,
            drop = FALSE
          ]
          
          shiny::div(
            class = "tbi-position-column",
            
            shiny::div(
              class = "tbi-position-header",
              pos
            ),
            
            shiny::div(
              class = "tbi-position-body",
              
              if (nrow(players) == 0) {
                
                shiny::div(
                  class = "tbi-empty-position",
                  "No player assigned"
                )
                
              } else {
                
                lapply(seq_len(nrow(players)), function(i) {
                  
                  player <- players[i, ]
                  
                  shiny::tags$button(
                    type = "button",
                    class = paste(
                      "tbi-player-card",
                      if (player$is_starter == 1) {
                        "tbi-player-starter"
                      } else {
                        "tbi-player-reserve"
                      }
                    ),
                    onclick = sprintf(
                      "Shiny.setInputValue('%s', %s, {priority: 'event'})",
                      session$ns("selected_player"),
                      player$player_id
                    ),
                    
                    shiny::div(
                      class = "tbi-player-rank",
                      if (player$is_starter == 1) {
                        "\u2605"
                      } else {
                        paste0("#", player$depth_order)
                      }
                    ),
                    
                    shiny::div(
                      class = "tbi-player-name",
                      player$player_name
                    ),
                    
                    shiny::div(
                      class = "tbi-player-details",
                      format_player_details(
                        age = player$player_age,
                        height_inches = player$height_inches,
                        weight_lbs = player$weight_lbs
                      )
                    )
                  )
                })
              }
            )
          )
        })
      )
    })
    
    return(
      list(
        selected_player_id = selected_player_id,
        roster_data = roster_data
      )
    )
  })
}


format_player_details <- function(
    age,
    height_inches,
    weight_lbs
) {
  age_text <- ifelse(
    is.na(age),
    "Age —",
    paste("Age", age)
  )
  
  height_text <- format_height(height_inches)
  
  weight_text <- ifelse(
    is.na(weight_lbs),
    "— lbs",
    paste0(weight_lbs, " lbs")
  )
  
  paste(
    age_text,
    height_text,
    weight_text,
    sep = " | "
  )
}


format_height <- function(height_inches) {
  if (is.na(height_inches)) {
    return("—")
  }
  
  feet <- floor(height_inches / 12)
  inches <- height_inches %% 12
  
  paste0(
    feet,
    "'",
    inches,
    '"'
  )
}