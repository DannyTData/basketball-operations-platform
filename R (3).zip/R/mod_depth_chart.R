mod_depth_chart_ui <- function(id) {
  ns <- NS(id)
  
  tagList(
    fluidRow(
      column(
        width = 4,
        selectInput(
          ns("team"),
          "Select Team",
          choices = NULL
        )
      )
    ),
    
    uiOutput(ns("depth_chart_ui"))
  )
}


mod_depth_chart_server <- function(id, db_path = "inst/database/tbi.sqlite") {
  moduleServer(id, function(input, output, session) {
    
    ns <- session$ns
    
    con <- DBI::dbConnect(
      RSQLite::SQLite(),
      db_path
    )
    
    session$onSessionEnded(function() {
      DBI::dbDisconnect(con)
    })
    
    teams <- DBI::dbGetQuery(
      con,
      "
      SELECT team_id, team_name
      FROM teams
      ORDER BY team_name
      "
    )
    
    updateSelectInput(
      session,
      "team",
      choices = setNames(
        teams$team_id,
        teams$team_name
      ),
      selected = teams$team_id[
        teams$team_name == "Boston Celtics"
      ]
    )
    
    depth_chart_data <- reactive({
      req(input$team)
      
      DBI::dbGetQuery(
        con,
        "
        SELECT
            dc.player_id,
            p.player_name,
            dc.position,
            dc.depth_order,
            dc.is_starter,
            p.player_age,
            p.height_inches,
            p.weight_lbs
        FROM depth_chart dc
        INNER JOIN players p
            ON dc.player_id = p.player_id
        WHERE dc.team_id = ?
        ORDER BY
            CASE dc.position
                WHEN 'PG' THEN 1
                WHEN 'SG' THEN 2
                WHEN 'SF' THEN 3
                WHEN 'PF' THEN 4
                WHEN 'C' THEN 5
                ELSE 6
            END,
            dc.depth_order
        ",
        params = list(as.integer(input$team))
      )
    })
    
    output$depth_chart_ui <- renderUI({
      chart <- depth_chart_data()
      
      req(nrow(chart) > 0)
      
      positions <- c("PG", "SG", "SF", "PF", "C")
      
      fluidRow(
        lapply(positions, function(pos) {
          
          position_players <- chart[
            chart$position == pos,
          ]
          
          column(
            width = 12,
            
            div(
              class = "depth-position-section",
              
              tags$h3(
                class = "depth-position-title",
                pos
              ),
              
              if (nrow(position_players) == 0) {
                
                div(
                  class = "depth-empty",
                  "No player assigned"
                )
                
              } else {
                
                lapply(
                  seq_len(nrow(position_players)),
                  function(i) {
                    
                    player <- position_players[i, ]
                    
                    div(
                      class = paste(
                        "depth-player-card",
                        if (player$is_starter == 1) {
                          "depth-starter"
                        } else {
                          "depth-reserve"
                        }
                      ),
                      
                      div(
                        class = "depth-player-order",
                        paste0("#", player$depth_order)
                      ),
                      
                      div(
                        class = "depth-player-info",
                        
                        tags$strong(
                          player$player_name
                        ),
                        
                        tags$span(
                          paste0(
                            "Age ",
                            player$player_age,
                            " | ",
                            player$height_inches,
                            " in | ",
                            player$weight_lbs,
                            " lbs"
                          )
                        )
                      ),
                      
                      if (player$is_starter == 1) {
                        tags$span(
                          class = "depth-starter-badge",
                          "Starter"
                        )
                      }
                    )
                  }
                )
              }
            )
          )
        })
      )
    })
  })
}